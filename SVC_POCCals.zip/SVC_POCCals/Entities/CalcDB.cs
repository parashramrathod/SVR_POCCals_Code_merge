﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using SVR_POCCals.DbModels;

namespace SVR_POCCals.Entities
{
    public class CalcDB
    {
        MySqlConnection connection;
        public CalcDB()
        {
            string connectionstring = "Server=localhost;Port=3306;User=root;Password=Nmysql;Database=calculatorDb;";
            connection = new MySqlConnection(connectionstring);
        }

        public void LogInfo(string logmessage)
        {
            try
            {
                Log objlog = new Log();
                objlog.Ipaddress = GetIp();
                objlog.LogMessage = logmessage;
                objlog.UserId = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                string cmdstring = "INSERT INTO calculatorDb.Log (LogMessage, IPAddress, UserID, LogDateTime)VALUES(@LogMessage, @IPAddress, @UserID, curdate()); ";
                connection.Open();
                using (MySqlCommand cmd = new MySqlCommand(cmdstring, connection))
                {
                    cmd.Connection = connection;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandType = System.Data.CommandType.Text;

                    cmd.Parameters.AddWithValue("@LogMessage", logmessage);
                    cmd.Parameters.AddWithValue("@IPAddress", objlog.Ipaddress);
                    cmd.Parameters.AddWithValue("@UserID", objlog.UserId);

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static string GetIp()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("No network adapters with an IP address in the system!");
        }
    }
}
