﻿using MySql.Data.MySqlClient;
using SVR_POCCals.DbModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace SVR_POCCals.Entities
{
    public class CalcDBContext
    {
        MySqlConnection con;
        public CalcDBContext()
        {
            string conString = "Server=localhost;Database=calculatorDB;Uid=root;Pwd=Nmysql;";
            con = new MySqlConnection(conString);
            con.Open();
        }
        public void SaveLogOperation(string operation)
        {
            Log log = new Log();
           
            log.Ipaddress = GetLocalIPAddress();
            log.LogMessage = operation;
            log.UserId = System.Security.Principal.WindowsIdentity.GetCurrent().Name;



            string cmdString = "insert into Log(LogMessage,IPAddress,UserID,LogDateTime) values(@LogMessage,@IPAddress,@UserID,@LogDateTime)";
          

            using (MySqlCommand command = new MySqlCommand(cmdString, con))
            {

                command.Connection = con;
                
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@LogMessage", log.LogMessage);
                command.Parameters.AddWithValue("@IPAddress", log.Ipaddress);
                command.Parameters.AddWithValue("@UserID", log.UserId);
                command.Parameters.AddWithValue("@LogDateTime", DateTime.Now);

                command.ExecuteNonQuery();
                con.Close();
            }
        }

        public static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("No network adapters with an IPv4 address in the system!");
        }
    }
}
