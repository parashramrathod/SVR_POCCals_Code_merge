﻿using System;
using System.Collections.Generic;

namespace SVR_POCCals.DbModels
{
    public partial class Efmigrationshistory
    {
        public string MigrationId { get; set; }
        public string ProductVersion { get; set; }
    }
}
