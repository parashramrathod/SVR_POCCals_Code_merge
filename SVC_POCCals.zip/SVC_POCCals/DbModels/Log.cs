﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SVR_POCCals.DbModels
{
    public partial class Log
    {
        public int LogId { get; set; }
        public string LogMessage { get; set; }
        public string Ipaddress { get; set; }
        public string UserId { get; set; }
        public DateTime LogDateTime { get; set; }
    }
}
