﻿using System;
using System.Collections.Generic;

namespace SVR_POCCals.DbModels
{
    public partial class TblAuthenticate
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}
