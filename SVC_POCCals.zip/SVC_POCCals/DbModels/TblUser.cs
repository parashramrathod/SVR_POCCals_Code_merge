﻿using System;
using System.Collections.Generic;

namespace SVR_POCCals.DbModels
{
    public partial class TblUser
    {
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
