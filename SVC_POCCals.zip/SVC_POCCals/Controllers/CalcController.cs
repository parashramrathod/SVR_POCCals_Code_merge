﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SVR_POCCals.DbModels;
using SVR_POCCals.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace SVR_POCCals.Controllers
{
    [Authorize]
    [Route("[controller]")]
    [ApiController]
    public class CalcController : ControllerBase
    {
        public CalcDBContext DBConnection { get; private set; }

        [ProducesResponseType(typeof(float), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IEnumerable<Log>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
     //   [ProducesResponseType(typeof(IEnumerable<Log>), (int)HttpStatusCode.BadRequest)]

        [HttpGet]
        //public async Task<IActionResult> Get(float num1, float num2, int operation)
       public double Get(double num1, double num2, int operation)
        {
            CalcDBContext objdb = new CalcDBContext();
            double result = 0;
            if (num1 > 0 && num2 > 0)
            {
                if (operation == 2)
                    result = PerformSubtraction(num1, num2);

                objdb.SaveLogOperation("Subtraction of : " + result);
               // objdb.SaveLogOperation("Operation performed successfully");

            }
            else
            {
                objdb.SaveLogOperation("Error values must be greater then zero");
            }           

            return result;
        }

        public double PerformSubtraction(double num1, double num2)
        {
            return num1 - num2;
        }
    }
}
