﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SVR_POCCals.Entities;
using SVR_POCCals.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SVR_POCCals.Controllers
{
    [Authorize]
    [Route("[controller]")]
    [ApiController]
    public class CalculatorController : ControllerBase
    {
        Calculator oCalc = new Calculator();
        CalcDB db = new CalcDB();
        [HttpGet]
        public double Get(double paramOne, double paramTwo, string operation)
        {
            oCalc.A = paramOne; oCalc.B = paramTwo; oCalc.Operation = operation;
            if (oCalc.Operation == "addition")
            { oCalc.Result = oCalc.A + oCalc.B; }
            if (oCalc.Operation == "subtraction")
            { oCalc.Result = oCalc.A - oCalc.B; }
            if (oCalc.Operation == "multiplication")
            { oCalc.Result = oCalc.A * oCalc.B; }

            oCalc.Logmessage = "The " + oCalc.Operation + " of " + oCalc.A + " and " + oCalc.B + " is " + oCalc.Result;

            //var result = _CalculatorDBContext.Log.ToList();
            //return Ok(result);
            db.LogInfo(oCalc.Logmessage);

            return oCalc.Result;

        }
    }
}
