﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SVR_POCCals.Models
{
    public class Calculator
    {
        public float Add(float fn, float sn)
        { return (sn + fn); }


        public double A { get; set; }
        public double B { get; set; }
        public double Result { get; set; }
        public string Operation { get; set; }

        public string Logmessage { get; set; }
    }
}
